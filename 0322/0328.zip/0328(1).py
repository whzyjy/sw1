'''2023.03.28
첫번째 프로그램
왕호진'''

su1=47
su2=47


print(su1,"과",su2,"합은",su1+su2)
print(su1,"과",su2,"차는",su1-su2)
print(su1,"과",su2,"곱은",su1*su2)
print(su1,"과",su2,"나눗셈은",su1/su2)
