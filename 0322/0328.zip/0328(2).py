'''2023.03.28
첫번째 프로그램
왕호진'''

radius=23
area=0
area=radius*radius*3.14

print("반지름이",radius,"합은",area)