'''2023.03.28
첫번째 프로그램
왕호진'''

num1=23
num2=34
num3=13
app=0

app=((num1+num2)*num3)/2

print("사다리꼴 넓이",app)