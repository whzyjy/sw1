'''2023.03.28
첫번째 프로그램
왕호진'''

num1=10
num2=5

res1=num1*num2
res2=num1/num2
res3=num1//num2
res4=num1%num2

print("num1*num2",res1)
print("num1/num2",res2)
print("num1//num2",res3)
print("num1%num2",res4)